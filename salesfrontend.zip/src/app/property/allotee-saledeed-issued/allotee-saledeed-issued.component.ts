import { Component } from '@angular/core';

@Component({
  selector: 'app-allotee-saledeed-issued',
  standalone: true,
  imports: [],
  templateUrl: './allotee-saledeed-issued.component.html',
  styleUrl: './allotee-saledeed-issued.component.scss'
})
export class AlloteeSaledeedIssuedComponent {

}
