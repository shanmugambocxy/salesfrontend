import { Component } from '@angular/core';

@Component({
  selector: 'app-customerdashboard',
  standalone: true,
  imports: [],
  templateUrl: './customerdashboard.component.html',
  styleUrl: './customerdashboard.component.scss'
})
export class CustomerdashboardComponent {


  ngOnInit() {

  }

}
